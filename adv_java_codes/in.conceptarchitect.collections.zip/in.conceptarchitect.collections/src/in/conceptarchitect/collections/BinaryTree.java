package in.conceptarchitect.collections;

public class BinaryTree {
	class Node {

		int value;
		Node left;
		Node right;
	}
}
